# Week 3 Lab: Verification

Fill out this readme as required by lab guidance

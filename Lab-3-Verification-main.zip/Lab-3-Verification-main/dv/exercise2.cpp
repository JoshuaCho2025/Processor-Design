#include <VExercise2.h>

int main() {
  VExercise2 model;
}

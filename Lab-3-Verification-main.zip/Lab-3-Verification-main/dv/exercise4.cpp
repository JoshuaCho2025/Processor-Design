#include <VExercise4.h>

int main() {
  VExercise4 model;
}

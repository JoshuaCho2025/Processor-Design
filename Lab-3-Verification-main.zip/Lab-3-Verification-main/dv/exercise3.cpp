#include <VExercise3.h>

int main() {
  VExercise3 model;
}

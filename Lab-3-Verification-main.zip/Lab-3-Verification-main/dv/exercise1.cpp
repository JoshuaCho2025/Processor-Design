#include <VExercise1.h>

int main() {
  VExercise1 model;
  jfioeajfieoa
  fjeioajfeioa
  jaiofejiaoe
}
